/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FactorialPipe } from './factorial.pipe';

describe('FactorialPipe', () => {
  it('create an instance', () => {
    const pipe = new FactorialPipe();
    expect(pipe).toBeTruthy();
  });
});
