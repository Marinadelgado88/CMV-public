/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SumatorioPipe } from './sumatorio.pipe';

describe('SumatorioPipe', () => {
  it('create an instance', () => {
    const pipe = new SumatorioPipe();
    expect(pipe).toBeTruthy();
  });
});
