/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CuadradoPipe } from './cuadrado.pipe';

describe('CuadradoPipe', () => {
  it('create an instance', () => {
    const pipe = new CuadradoPipe();
    expect(pipe).toBeTruthy();
  });
});
