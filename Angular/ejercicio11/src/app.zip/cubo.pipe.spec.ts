/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CuboPipe } from './cubo.pipe';

describe('CuboPipe', () => {
  it('create an instance', () => {
    const pipe = new CuboPipe();
    expect(pipe).toBeTruthy();
  });
});
