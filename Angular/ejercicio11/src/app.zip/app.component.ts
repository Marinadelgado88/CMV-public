import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'EJERCICIO 79';

  num1:number;
  num2:number;
  num3:number;
  num4:number;
  num5:number;
  num6:number;
}
