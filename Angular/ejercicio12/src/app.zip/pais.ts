import {Persona} from './persona';

export class Pais {
    constructor(public comunidad:string, public provincia:string, public persona :Persona[]) {
    }
}
