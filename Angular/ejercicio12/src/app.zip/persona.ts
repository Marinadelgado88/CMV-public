

export class Persona {
    constructor(public nombre:string, public apellido:string, public edad:number, public dni:string) {
    }
}
