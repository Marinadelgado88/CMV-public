
import {Pais} from './pais';

export class Continente {
    constructor(public nombre:string, public pais: Pais[]) {
    }
}
