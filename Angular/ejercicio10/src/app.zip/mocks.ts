import{ Libro } from'./libro.model';

export const LIBROS: Libro[] = [{
  "id": 1,
  "titulo": "Romeo y Julieta",
  "autor": "William Shakespeare"
},{
  "id": 2,
  "titulo": "El Lazarillo de Tormes",
  "autor": "anónima"
}];
